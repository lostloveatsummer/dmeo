package com.wsl.service;

import com.wsl.bean.User;

public interface LoginService{

    User getUserByName(String userName);
}
